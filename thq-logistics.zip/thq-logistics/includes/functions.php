<?php
/** Shared helper functions used across the site and admin panel. */

/** Escape output for safe HTML display. */
function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

/** All statuses a shipment can move through, in order. */
function thq_statuses() {
    return ['Pending', 'Picked Up', 'In Transit', 'At Hub', 'Out for Delivery', 'Delivered', 'Delayed', 'Cancelled'];
}

function thq_service_types() {
    return ['Standard', 'Express', 'Overnight'];
}

function thq_payment_statuses() {
    return ['Pending', 'Paid', 'COD'];
}

/** Generate a unique tracking code like THQ-AB12-CD34-EFG. */
function thq_generate_tracking_code(PDO $pdo) {
    $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no I, O, 0, 1 - avoids confusion
    do {
        $code = THQ_TRACKING_PREFIX . '-';
        for ($i = 0; $i < 4; $i++) $code .= $chars[random_int(0, strlen($chars) - 1)];
        $code .= '-';
        for ($i = 0; $i < 4; $i++) $code .= $chars[random_int(0, strlen($chars) - 1)];
        $code .= '-';
        for ($i = 0; $i < 3; $i++) $code .= $chars[random_int(0, strlen($chars) - 1)];

        $stmt = $pdo->prepare('SELECT COUNT(*) FROM shipments WHERE tracking_code = ?');
        $stmt->execute([$code]);
        $exists = (int)$stmt->fetchColumn() > 0;
    } while ($exists);

    return $code;
}

/** CSS badge class for a given status, used in both admin and public views. */
function thq_status_badge_class($status) {
    switch ($status) {
        case 'Delivered': return 'badge-delivered';
        case 'Pending': return 'badge-pending';
        case 'Cancelled': return 'badge-cancel';
        case 'Delayed': return 'badge-delayed';
        default: return 'badge-transit'; // Picked Up, In Transit, At Hub, Out for Delivery
    }
}

/** Redirect helper. */
function thq_redirect($path) {
    header('Location: ' . $path);
    exit;
}

/** One-time flash message stored in the session (survives exactly one redirect). */
function thq_flash_set($message, $type = 'success') {
    $_SESSION['thq_flash'] = ['message' => $message, 'type' => $type];
}
function thq_flash_get() {
    if (empty($_SESSION['thq_flash'])) return null;
    $flash = $_SESSION['thq_flash'];
    unset($_SESSION['thq_flash']);
    return $flash;
}

/** CSRF token helpers - one token per session, checked on every state-changing form. */
function thq_csrf_token() {
    if (empty($_SESSION['thq_csrf'])) {
        $_SESSION['thq_csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['thq_csrf'];
}
function thq_csrf_field() {
    return '<input type="hidden" name="csrf_token" value="' . e(thq_csrf_token()) . '">';
}
function thq_csrf_check() {
    $token = $_POST['csrf_token'] ?? '';
    if (!$token || !hash_equals($_SESSION['thq_csrf'] ?? '', $token)) {
        http_response_code(400);
        die('Security check failed. Please go back and try again.');
    }
}

/** Fetch one shipment (by id) with its full status history, or null if not found. */
function thq_get_shipment($pdo, $id) {
    $stmt = $pdo->prepare('SELECT * FROM shipments WHERE id = ?');
    $stmt->execute([$id]);
    $shipment = $stmt->fetch();
    if (!$shipment) return null;

    $stmt = $pdo->prepare('SELECT * FROM status_history WHERE shipment_id = ? ORDER BY id ASC');
    $stmt->execute([$id]);
    $shipment['history'] = $stmt->fetchAll();

    return $shipment;
}

/** Fetch one shipment by its public tracking code. */
function thq_get_shipment_by_code($pdo, $code) {
    $stmt = $pdo->prepare('SELECT id FROM shipments WHERE tracking_code = ?');
    $stmt->execute([$code]);
    $row = $stmt->fetch();
    if (!$row) return null;
    return thq_get_shipment($pdo, $row['id']);
}

/** Sanitize a plain text field from $_POST: trims and strips tags. */
function thq_text($key, $default = '') {
    $value = $_POST[$key] ?? $default;
    return trim(strip_tags((string)$value));
}
