<?php
/** Minimal session-based auth for the standalone admin panel. */

function thq_admin_exists($pdo) {
    $stmt = $pdo->query('SELECT COUNT(*) FROM admin_users');
    return (int)$stmt->fetchColumn() > 0;
}

function thq_create_admin($pdo, $username, $password) {
    $stmt = $pdo->prepare('INSERT INTO admin_users (username, password_hash) VALUES (?, ?)');
    $stmt->execute([$username, password_hash($password, PASSWORD_DEFAULT)]);
    return $pdo->lastInsertId();
}

function thq_attempt_login($pdo, $username, $password) {
    $stmt = $pdo->prepare('SELECT * FROM admin_users WHERE username = ?');
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    if ($user && password_verify($password, $user['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['thq_admin_id'] = $user['id'];
        $_SESSION['thq_admin_username'] = $user['username'];
        return true;
    }
    return false;
}

function thq_is_logged_in() {
    return !empty($_SESSION['thq_admin_id']);
}

function thq_current_admin_username() {
    return $_SESSION['thq_admin_username'] ?? null;
}

function thq_logout() {
    unset($_SESSION['thq_admin_id'], $_SESSION['thq_admin_username']);
    session_regenerate_id(true);
}

/** Call at the top of any admin page that requires a logged-in user. */
function thq_require_login() {
    if (!thq_is_logged_in()) {
        thq_redirect('login.php');
    }
}
