<?php
/**
 * Database layer - SQLite via PDO.
 * No server setup needed: the .db file is created automatically on first run.
 */

function thq_db() {
    static $pdo = null;
    if ($pdo !== null) return $pdo;

    if (!is_dir(THQ_DATA_DIR)) {
        mkdir(THQ_DATA_DIR, 0755, true);
    }

    $isNew = !file_exists(THQ_DB_FILE);

    $pdo = new PDO('sqlite:' . THQ_DB_FILE);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->exec('PRAGMA foreign_keys = ON');

    thq_db_migrate($pdo);

    // Lock down the data directory the first time we create it.
    if ($isNew) {
        @file_put_contents(THQ_DATA_DIR . '/.htaccess', "Require all denied\n" . "Deny from all\n");
        @file_put_contents(THQ_DATA_DIR . '/index.php', "<?php // Silence is golden\n");
    }

    return $pdo;
}

function thq_db_migrate(PDO $pdo) {
    $pdo->exec("CREATE TABLE IF NOT EXISTS shipments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tracking_code TEXT UNIQUE NOT NULL,
        sender_name TEXT DEFAULT '',
        sender_phone TEXT DEFAULT '',
        sender_email TEXT DEFAULT '',
        sender_address TEXT DEFAULT '',
        receiver_name TEXT DEFAULT '',
        receiver_phone TEXT DEFAULT '',
        receiver_email TEXT DEFAULT '',
        receiver_address TEXT DEFAULT '',
        origin_city TEXT DEFAULT '',
        destination_city TEXT DEFAULT '',
        item_name TEXT DEFAULT '',
        item_description TEXT DEFAULT '',
        quantity INTEGER DEFAULT 1,
        weight REAL DEFAULT 0,
        length REAL DEFAULT 0,
        width REAL DEFAULT 0,
        height REAL DEFAULT 0,
        declared_value REAL DEFAULT 0,
        is_fragile TEXT DEFAULT 'no',
        service_type TEXT DEFAULT 'Standard',
        shipping_cost REAL DEFAULT 0,
        payment_status TEXT DEFAULT 'Pending',
        current_status TEXT DEFAULT 'Pending',
        estimated_delivery TEXT DEFAULT '',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS status_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        shipment_id INTEGER NOT NULL,
        status TEXT NOT NULL,
        location TEXT DEFAULT '',
        note TEXT DEFAULT '',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (shipment_id) REFERENCES shipments(id) ON DELETE CASCADE
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS admin_users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS quote_requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT DEFAULT '',
        email TEXT DEFAULT '',
        service TEXT DEFAULT '',
        weight TEXT DEFAULT '',
        message TEXT DEFAULT '',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )");

    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_shipments_tracking_code ON shipments(tracking_code)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_history_shipment_id ON status_history(shipment_id)");
}
