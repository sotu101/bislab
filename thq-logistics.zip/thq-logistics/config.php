<?php
/**
 * THQ Logistics - Core Configuration
 * Standalone PHP app (no WordPress required). Uses a local SQLite file for storage.
 */

// ---- Basic setup ----
error_reporting(E_ALL);
ini_set('display_errors', '0'); // set to '1' temporarily if you need to debug

date_default_timezone_set('Africa/Lagos');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ---- Paths ----
define('THQ_ROOT', __DIR__);
define('THQ_DATA_DIR', THQ_ROOT . '/data');
define('THQ_DB_FILE', THQ_DATA_DIR . '/shipments.db');

// Base URL (auto-detected). If your site lives in a subfolder, this still works
// because it's built from the actual request path.
function thq_base_url() {
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host   = $_SERVER['HTTP_HOST'] ?? 'localhost';
    // Directory of the currently executing top-level script, relative to web root
    $scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
    // Strip a trailing /admin or /api so links always resolve to the site root
    $scriptDir = preg_replace('#/(admin|api)(/.*)?$#', '', $scriptDir);
    $scriptDir = rtrim($scriptDir, '/');
    return $scheme . '://' . $host . $scriptDir;
}
define('THQ_BASE_URL', thq_base_url());

// ---- Brand ----
define('THQ_BRAND_NAME', 'THQ Logistics');
define('THQ_TRACKING_PREFIX', 'THQ');
define('THQ_CURRENCY', '₦');

require_once THQ_ROOT . '/includes/db.php';
require_once THQ_ROOT . '/includes/functions.php';
require_once THQ_ROOT . '/includes/auth.php';
