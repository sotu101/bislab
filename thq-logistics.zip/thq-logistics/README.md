# THQ Logistics — Standalone Tracking Site

This is a **fully standalone PHP application** — no WordPress required. It combines your
THQ Logistics marketing site with a real shipment-tracking backend, plus a plain HTML/PHP
admin panel to manage shipments.

## What's inside

```
thq-logistics/
├── index.php              ← public site (homepage + live tracking box + quote form)
├── config.php              ← app configuration (timezone, paths, brand)
├── includes/
│   ├── db.php               ← SQLite connection + auto-creates tables on first run
│   ├── functions.php        ← tracking code generator, helpers
│   └── auth.php              ← admin login/session logic
├── api/
│   ├── track.php             ← JSON endpoint the homepage calls to look up a shipment
│   └── quote.php             ← JSON endpoint that saves the "Get a Quote" form
├── admin/
│   ├── login.php              ← admin login (first visit lets you create the account)
│   ├── dashboard.php           ← stats + recent shipments
│   ├── shipments.php            ← search/filter/delete all shipments
│   ├── add-shipment.php          ← ★ standalone HTML form to add a new parcel
│   └── edit-shipment.php          ← edit a shipment / log a status update
└── data/                    ← auto-created — holds shipments.db (SQLite file)
```

## Requirements

- PHP 7.4 or newer (PHP 8.x fine) with the `pdo_sqlite` extension — this is enabled by
  default on almost all shared hosting (cPanel, etc.) and on services like Hostinger,
  Namecheap, or a basic VPS. No MySQL, no WordPress, nothing else to install.

## Installation

1. Upload the whole `thq-logistics` folder to your web host (e.g. `public_html/`).
2. Make sure the `data/` folder is **writable** by PHP (most hosts default to this;
   if not, `chmod 755 data`).
3. Visit your domain in a browser. The site loads immediately — the database is created
   automatically the first time any page runs.
4. Go to `yourdomain.com/admin/login.php`. Since no admin account exists yet, you'll be
   asked to **create one** (username + password). This only happens once.
5. You're in. Click **+ Add New** to create your first shipment.

## How it's wired together

- **Public tracking** (the box on the homepage) calls `api/track.php`, which queries the
  real SQLite database — no more fake/simulated results.
- **Adding a parcel** happens on its own page, `admin/add-shipment.php` — separate from
  the dashboard, exactly so you can create shipments quickly without digging through
  other admin screens. It auto-generates a unique tracking code (`THQ-XXXX-XXXX-XXX`).
- **Editing a shipment / updating its status** happens on `admin/edit-shipment.php` —
  every status change you log there instantly shows up in the public tracking timeline.
- The **"Get a Quote" form** on the homepage now saves real leads to the database via
  `api/quote.php` (currently just stored — wire up email notifications later if you want).

## Security notes

- Admin pages are protected by a login (session-based, passwords hashed with
  `password_hash()`), plus CSRF tokens on every form.
- The `data/` folder (where the database file lives) is protected with a `.htaccess`
  deny-all rule. If your host runs **Nginx** instead of Apache, `.htaccess` won't apply —
  in that case, move the `data/` folder one level *above* your web root and update
  `THQ_DATA_DIR` in `config.php` to point to it.
- Change the tracking-code prefix, currency symbol, or timezone in `config.php`.

## Growing beyond SQLite

SQLite (a single file, zero setup) is what this ships with. If your shipment volume grows
and you want MySQL instead, only `includes/db.php` needs to change — everything else talks
to the database through the small helper functions in `includes/functions.php`, so the rest
of the app doesn't need to change.
