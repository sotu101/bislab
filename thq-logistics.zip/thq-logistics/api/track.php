<?php
require_once __DIR__ . '/../config.php';

header('Content-Type: application/json');

$code = strtoupper(trim($_GET['code'] ?? $_POST['code'] ?? ''));

if ($code === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Please enter a tracking code.']);
    exit;
}

$pdo = thq_db();
$shipment = thq_get_shipment_by_code($pdo, $code);

if (!$shipment) {
    http_response_code(404);
    echo json_encode(['success' => false, 'message' => 'Tracking code not found. Please check and try again.']);
    exit;
}

$history = array_map(function ($h) {
    return [
        'status'    => $h['status'],
        'location'  => $h['location'],
        'note'      => $h['note'],
        'timestamp' => $h['created_at'],
    ];
}, $shipment['history']);

echo json_encode([
    'success' => true,
    'data' => [
        'code'        => $shipment['tracking_code'],
        'status'      => $shipment['current_status'] ?: 'Pending',
        'origin'      => $shipment['origin_city'],
        'destination' => $shipment['destination_city'],
        'receiver'    => $shipment['receiver_name'],
        'sender'      => $shipment['sender_name'],
        'item'        => $shipment['item_name'],
        'weight'      => $shipment['weight'],
        'service'     => $shipment['service_type'],
        'estimated'   => $shipment['estimated_delivery'],
        'history'     => $history,
    ],
]);
