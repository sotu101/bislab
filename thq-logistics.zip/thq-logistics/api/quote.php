<?php
require_once __DIR__ . '/../config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed.']);
    exit;
}

$name    = thq_text('name');
$email   = thq_text('email');
$service = thq_text('service');
$weight  = thq_text('weight');
$message = thq_text('message');

if ($name === '' || $email === '') {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Name and email are required.']);
    exit;
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Please enter a valid email address.']);
    exit;
}

$pdo = thq_db();
$stmt = $pdo->prepare('INSERT INTO quote_requests (name, email, service, weight, message) VALUES (?,?,?,?,?)');
$stmt->execute([$name, $email, $service, $weight, $message]);

echo json_encode(['success' => true, 'message' => 'Quote request submitted! Our specialists will reach out within 15 minutes.']);
