<?php
require_once __DIR__ . '/config.php';

$pdo = thq_db();
$totalShipments = (int)$pdo->query('SELECT COUNT(*) FROM shipments')->fetchColumn();
$inTransitCount = (int)$pdo->query("SELECT COUNT(*) FROM shipments WHERE current_status IN ('In Transit','At Hub','Out for Delivery')")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>THQ Logistics | Global Supply Chain Solutions</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <!-- FontAwesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-slate-50 text-slate-800 font-sans scroll-smooth">

    <!-- NAVBAR -->
    <nav class="sticky top-0 z-50 bg-slate-900 text-white shadow-md">
        <div class="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
            <a href="#" class="text-2xl font-black tracking-wider text-amber-500 flex items-center gap-2">
                <i class="fa-solid fa-truck-fast"></i> THQ <span class="text-white font-light">LOGISTICS</span>
            </a>
            <div class="hidden md:flex space-x-8 font-medium">
                <a href="#home" class="hover:text-amber-500 transition-colors">Home</a>
                <a href="#services" class="hover:text-amber-500 transition-colors">Services</a>
                <a href="#track" class="hover:text-amber-500 transition-colors">Track Shipment</a>
                <a href="#about" class="hover:text-amber-500 transition-colors">Why Us</a>
                <a href="#contact" class="hover:text-amber-500 transition-colors">Contact</a>
            </div>
            <a href="#track" class="bg-amber-500 hover:bg-amber-600 text-slate-950 px-5 py-2 rounded-full font-bold text-sm transition-all shadow-md">
                Quick Track
            </a>
        </div>
    </nav>

    <!-- HERO SECTION -->
    <section id="home" class="relative bg-slate-900 text-white overflow-hidden py-24 lg:py-32">
        <div class="absolute inset-0 opacity-20">
            <div class="absolute inset-0 bg-[radial-gradient(#334155_1px,transparent_1px)] [background-size:16px_16px]"></div>
        </div>
        <div class="relative max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-12 items-center">
            <div class="space-y-6">
                <span class="text-amber-500 font-bold tracking-widest uppercase text-sm block">Smart Logistics Solutions</span>
                <h1 class="text-4xl md:text-6xl font-extrabold leading-tight">
                    Global Reach.<br><span class="text-amber-500">Local Trust.</span> Swift Delivery.
                </h1>
                <p class="text-slate-400 text-lg max-w-lg">
                    THQ Logistics streamlines your supply chain with precision, advanced tracking technology, and a global network that keeps your business moving forward.
                </p>
                <div class="flex flex-wrap gap-4 pt-2">
                    <a href="#contact" class="bg-amber-500 hover:bg-amber-600 text-slate-950 px-8 py-3 rounded-lg font-bold transition-all shadow-lg">
                        Get a Free Quote
                    </a>
                    <a href="#services" class="border border-slate-700 hover:border-slate-500 bg-slate-800/50 px-8 py-3 rounded-lg font-semibold transition-all">
                        Our Services
                    </a>
                </div>
            </div>
            <!-- Live Network Status - now pulled from the real database -->
            <div class="bg-slate-800/80 p-6 md:p-8 rounded-2xl border border-slate-700/50 backdrop-blur-sm shadow-2xl">
                <div class="flex items-center justify-between border-b border-slate-700 pb-4 mb-6">
                    <h3 class="font-bold text-lg text-slate-200">Live Network Status</h3>
                    <span class="flex items-center gap-2 text-xs bg-emerald-500/10 text-emerald-400 px-3 py-1 rounded-full font-semibold">
                        <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span> Systems Operational
                    </span>
                </div>
                <div class="space-y-4">
                    <div class="flex justify-between text-sm text-slate-400">
                        <span>Total Shipments Handled</span>
                        <span class="font-mono text-white font-bold"><?php echo number_format($totalShipments); ?></span>
                    </div>
                    <div class="flex justify-between text-sm text-slate-400">
                        <span>Currently In Transit</span>
                        <span class="font-mono text-amber-400 font-bold"><?php echo number_format($inTransitCount); ?></span>
                    </div>
                    <div class="grid grid-cols-3 gap-4 pt-4 text-center">
                        <div class="bg-slate-900/50 p-3 rounded-lg">
                            <i class="fa-solid fa-plane text-amber-500 mb-1"></i>
                            <div class="text-xs text-slate-400">Air Freight</div>
                            <div class="font-bold text-sm">99.4% On-Time</div>
                        </div>
                        <div class="bg-slate-900/50 p-3 rounded-lg">
                            <i class="fa-solid fa-ship text-amber-500 mb-1"></i>
                            <div class="text-xs text-slate-400">Ocean</div>
                            <div class="font-bold text-sm">42 Countries</div>
                        </div>
                        <div class="bg-slate-900/50 p-3 rounded-lg">
                            <i class="fa-solid fa-truck text-amber-500 mb-1"></i>
                            <div class="text-xs text-slate-400">Ground</div>
                            <div class="font-bold text-sm">24/7 Dispatch</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- TRACKING SECTION - now backed by the real database via api/track.php -->
    <section id="track" class="max-w-4xl mx-auto px-6 -mt-12 relative z-10">
        <div class="bg-white rounded-2xl shadow-xl p-6 md:p-8 border border-slate-100">
            <h3 class="text-xl font-bold mb-4 flex items-center gap-2 text-slate-900">
                <i class="fa-solid fa-magnifying-glass-location text-amber-500"></i> Track Your Shipment
            </h3>
            <div class="flex flex-col sm:flex-row gap-3">
                <input type="text" id="trackingInput" placeholder="e.g. THQ-AB12-CD34-EFG"
                    class="flex-1 px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 text-slate-900 uppercase">
                <button onclick="trackPackage()" class="bg-slate-900 hover:bg-slate-800 text-white px-6 py-3 rounded-lg font-bold transition-colors">
                    Track Now
                </button>
            </div>
            <!-- Dynamic Result Area -->
            <div id="trackingResult" class="mt-6 hidden p-4 rounded-xl border transition-all"></div>
        </div>
    </section>

    <!-- SERVICES SECTION -->
    <section id="services" class="max-w-7xl mx-auto px-6 py-24">
        <div class="text-center max-w-2xl mx-auto mb-16">
            <h2 class="text-3xl md:text-4xl font-extrabold text-slate-900 mb-4">End-to-End Logistics Services</h2>
            <p class="text-slate-600">No matter the destination, size, or urgency, THQ Logistics provides tailored solutions to optimize your supply chain.</p>
        </div>

        <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div class="bg-white p-8 rounded-2xl border border-slate-100 hover:shadow-xl transition-all group">
                <div class="w-12 h-12 bg-amber-500/10 text-amber-600 rounded-xl flex items-center justify-center text-xl font-bold mb-6 group-hover:bg-amber-500 group-hover:text-slate-950 transition-all">
                    <i class="fa-solid fa-plane-departure"></i>
                </div>
                <h3 class="text-xl font-bold text-slate-900 mb-2">Air Freight Forwarding</h3>
                <p class="text-slate-600 text-sm leading-relaxed">
                    When time is critical. Express global air transit with guaranteed space allocations and rapid customs clearance.
                </p>
            </div>
            <div class="bg-white p-8 rounded-2xl border border-slate-100 hover:shadow-xl transition-all group">
                <div class="w-12 h-12 bg-amber-500/10 text-amber-600 rounded-xl flex items-center justify-center text-xl font-bold mb-6 group-hover:bg-amber-500 group-hover:text-slate-950 transition-all">
                    <i class="fa-solid fa-ship"></i>
                </div>
                <h3 class="text-xl font-bold text-slate-900 mb-2">Ocean Freight</h3>
                <p class="text-slate-600 text-sm leading-relaxed">
                    Cost-effective deep-sea transport solutions for Full Container Load (FCL) and Less than Container Load (LCL) shipments.
                </p>
            </div>
            <div class="bg-white p-8 rounded-2xl border border-slate-100 hover:shadow-xl transition-all group">
                <div class="w-12 h-12 bg-amber-500/10 text-amber-600 rounded-xl flex items-center justify-center text-xl font-bold mb-6 group-hover:bg-amber-500 group-hover:text-slate-950 transition-all">
                    <i class="fa-solid fa-truck-moving"></i>
                </div>
                <h3 class="text-xl font-bold text-slate-900 mb-2">Overland Logistics</h3>
                <p class="text-slate-600 text-sm leading-relaxed">
                    Flexible and dependable domestic and cross-border trucking, dry van, refrigerated freight, and flatbed transport.
                </p>
            </div>
            <div class="bg-white p-8 rounded-2xl border border-slate-100 hover:shadow-xl transition-all group">
                <div class="w-12 h-12 bg-amber-500/10 text-amber-600 rounded-xl flex items-center justify-center text-xl font-bold mb-6 group-hover:bg-amber-500 group-hover:text-slate-950 transition-all">
                    <i class="fa-solid fa-warehouse"></i>
                </div>
                <h3 class="text-xl font-bold text-slate-900 mb-2">Warehousing & Storage</h3>
                <p class="text-slate-600 text-sm leading-relaxed">
                    Secure, climate-controlled, and fully managed inventory distribution centers optimized for rapid fulfillment.
                </p>
            </div>
            <div class="bg-white p-8 rounded-2xl border border-slate-100 hover:shadow-xl transition-all group">
                <div class="w-12 h-12 bg-amber-500/10 text-amber-600 rounded-xl flex items-center justify-center text-xl font-bold mb-6 group-hover:bg-amber-500 group-hover:text-slate-950 transition-all">
                    <i class="fa-solid fa-boxes-packing"></i>
                </div>
                <h3 class="text-xl font-bold text-slate-900 mb-2">Last-Mile Delivery</h3>
                <p class="text-slate-600 text-sm leading-relaxed">
                    The final, crucial step optimized through intelligent routing software to ensure parcel drops are fast and flawless.
                </p>
            </div>
            <div class="bg-white p-8 rounded-2xl border border-slate-100 hover:shadow-xl transition-all group">
                <div class="w-12 h-12 bg-amber-500/10 text-amber-600 rounded-xl flex items-center justify-center text-xl font-bold mb-6 group-hover:bg-amber-500 group-hover:text-slate-950 transition-all">
                    <i class="fa-solid fa-clipboard-check"></i>
                </div>
                <h3 class="text-xl font-bold text-slate-900 mb-2">Customs Brokerage</h3>
                <p class="text-slate-600 text-sm leading-relaxed">
                    Expert tariff classification, strict compliance management, and fast-track processing through international borders.
                </p>
            </div>
        </div>
    </section>

    <!-- WHY CHOOSE US -->
    <section id="about" class="bg-slate-950 text-white py-24">
        <div class="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-16 items-center">
            <div>
                <span class="text-amber-500 font-bold tracking-widest uppercase text-sm block mb-2">The THQ Advantage</span>
                <h2 class="text-3xl md:text-4xl font-extrabold mb-6">Why Industry Leaders Trust THQ Logistics</h2>
                <p class="text-slate-400 mb-8 leading-relaxed">
                    We combine years of operational expertise with state-of-the-art supply chain tech. We don't just move cargo; we optimize your overhead, minimize transit disruptions, and scale along with your business demands.
                </p>
                <div class="space-y-4">
                    <div class="flex items-start gap-4">
                        <div class="text-amber-500 mt-1"><i class="fa-solid fa-circle-check text-lg"></i></div>
                        <div>
                            <h4 class="font-bold text-lg">100% Real-Time Transparency</h4>
                            <p class="text-slate-400 text-sm">Know exactly where your inventory is at any hour of the day or night.</p>
                        </div>
                    </div>
                    <div class="flex items-start gap-4">
                        <div class="text-amber-500 mt-1"><i class="fa-solid fa-circle-check text-lg"></i></div>
                        <div>
                            <h4 class="font-bold text-lg">Global Footprint</h4>
                            <p class="text-slate-400 text-sm">Strategic partnerships spanning over 150 hub cities internationally.</p>
                        </div>
                    </div>
                    <div class="flex items-start gap-4">
                        <div class="text-amber-500 mt-1"><i class="fa-solid fa-circle-check text-lg"></i></div>
                        <div>
                            <h4 class="font-bold text-lg">Eco-Friendly Shipping Initiatives</h4>
                            <p class="text-slate-400 text-sm">Route optimization algorithms designed to drastically lower carbon footprints.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="grid grid-cols-2 gap-6">
                <div class="p-8 bg-slate-900 rounded-2xl border border-slate-800">
                    <div class="text-4xl font-black text-amber-500 mb-2">99.8%</div>
                    <div class="text-sm font-semibold text-slate-200">Delivery Success Rate</div>
                </div>
                <div class="p-8 bg-slate-900 rounded-2xl border border-slate-800">
                    <div class="text-4xl font-black text-amber-500 mb-2">24/7</div>
                    <div class="text-sm font-semibold text-slate-200">Live Support Dispatch</div>
                </div>
                <div class="p-8 bg-slate-900 rounded-2xl border border-slate-800">
                    <div class="text-4xl font-black text-amber-500 mb-2">1.2M+</div>
                    <div class="text-sm font-semibold text-slate-200">Tons Moved Annually</div>
                </div>
                <div class="p-8 bg-slate-900 rounded-2xl border border-slate-800">
                    <div class="text-4xl font-black text-amber-500 mb-2">15mins</div>
                    <div class="text-sm font-semibold text-slate-200">Avg. Quote Turnaround</div>
                </div>
            </div>
        </div>
    </section>

    <!-- CONTACT & QUOTE SECTION - now saved to the database via api/quote.php -->
    <section id="contact" class="max-w-7xl mx-auto px-6 py-24">
        <div class="grid lg:grid-cols-3 gap-12 bg-white rounded-3xl p-8 md:p-12 shadow-xl border border-slate-100">
            <div class="lg:col-span-1 space-y-6">
                <h2 class="text-3xl font-extrabold text-slate-900">Let's Get Moving</h2>
                <p class="text-slate-600">
                    Ready to scale up your logistics efficiency? Drop us a quick message, or request a complete customs route audit from our dispatch specialists.
                </p>
                <div class="space-y-4 pt-4 text-sm font-medium text-slate-700">
                    <div class="flex items-center gap-3">
                        <i class="fa-solid fa-envelope text-amber-500 text-base"></i> contact@thqlogistics.com
                    </div>
                    <div class="flex items-center gap-3">
                        <i class="fa-solid fa-phone text-amber-500 text-base"></i> +1 (800) 555-0199
                    </div>
                    <div class="flex items-center gap-3">
                        <i class="fa-solid fa-location-dot text-amber-500 text-base"></i> 100 Logistics Blvd, Suite 400, Chicago, IL
                    </div>
                </div>
            </div>

            <form id="quoteForm" class="lg:col-span-2 grid md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">Your Name</label>
                    <input type="text" name="name" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 text-slate-900">
                </div>
                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">Business Email</label>
                    <input type="email" name="email" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 text-slate-900">
                </div>
                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">Service Needed</label>
                    <select name="service" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 text-slate-900">
                        <option>Air Freight</option>
                        <option>Ocean Freight</option>
                        <option>Overland Freight</option>
                        <option>Warehousing Solution</option>
                    </select>
                </div>
                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">Estimated Weight (kg)</label>
                    <input type="number" name="weight" placeholder="e.g. 500" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 text-slate-900">
                </div>
                <div class="md:col-span-2">
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">Message or Special Requirements</label>
                    <textarea name="message" rows="4" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 text-slate-900"></textarea>
                </div>
                <div class="md:col-span-2 flex items-center justify-between gap-4">
                    <div id="quoteFeedback" class="text-sm font-semibold"></div>
                    <button type="submit" class="w-full sm:w-auto bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold px-8 py-3 rounded-xl transition-all shadow-md">
                        Submit Quote Request
                    </button>
                </div>
            </form>
        </div>
    </section>

    <!-- FOOTER -->
    <footer class="bg-slate-900 text-slate-400 py-12 border-t border-slate-800">
        <div class="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-6">
            <div class="text-xl font-black text-amber-500 tracking-wider">
                <i class="fa-solid fa-truck-fast"></i> THQ <span class="text-white font-light">LOGISTICS</span>
            </div>
            <div class="flex space-x-6 text-sm">
                <a href="#" class="hover:text-white transition-colors">Privacy Policy</a>
                <a href="#" class="hover:text-white transition-colors">Terms of Service</a>
                <a href="admin/login.php" class="hover:text-white transition-colors">Staff Login</a>
            </div>
            <p class="text-xs">&copy; <?php echo date('Y'); ?> THQ Logistics Inc. All rights reserved.</p>
        </div>
    </footer>

    <!-- LIVE TRACKING - talks to api/track.php, backed by the SQLite database -->
    <script>
        const THQ_API_BASE = <?php echo json_encode(THQ_BASE_URL); ?>;

        async function trackPackage() {
            const input = document.getElementById('trackingInput').value.trim();
            const resultBox = document.getElementById('trackingResult');

            if (!input) {
                resultBox.className = "mt-6 p-4 rounded-xl border bg-rose-50 border-rose-200 text-rose-700 font-semibold text-sm";
                resultBox.innerHTML = "<i class='fa-solid fa-circle-exclamation'></i> Please enter a tracking ID.";
                resultBox.classList.remove('hidden');
                return;
            }

            resultBox.classList.remove('hidden');
            resultBox.className = "mt-6 p-6 rounded-xl border bg-slate-100 border-slate-200 text-slate-600 text-sm";
            resultBox.innerHTML = "<i class='fa-solid fa-spinner fa-spin'></i> Searching...";

            try {
                const res = await fetch(`${THQ_API_BASE}/api/track.php?code=${encodeURIComponent(input)}`);
                const json = await res.json();

                if (!json.success) {
                    resultBox.className = "mt-6 p-4 rounded-xl border bg-rose-50 border-rose-200 text-rose-700 font-semibold text-sm";
                    resultBox.innerHTML = `<i class="fa-solid fa-circle-exclamation"></i> ${escapeHtml(json.message)}`;
                    return;
                }

                const d = json.data;
                const steps = ['Pending', 'Picked Up', 'In Transit', 'Out for Delivery', 'Delivered'];
                const curIdx = steps.indexOf(d.status);

                let stepper = '<div class="flex justify-between my-6 relative">';
                stepper += '<div class="absolute top-[18px] left-[10%] right-[10%] h-0.5 bg-slate-700"></div>';
                steps.forEach((s, idx) => {
                    let dotClasses = "w-9 h-9 rounded-full mx-auto mb-2 flex items-center justify-center text-xs font-bold relative z-10";
                    let icon = idx + 1;
                    if (idx < curIdx) { dotClasses += " bg-emerald-500 text-white"; icon = '<i class="fa-solid fa-check"></i>'; }
                    else if (idx === curIdx) { dotClasses += " bg-amber-500 text-slate-950 ring-4 ring-amber-500/20"; }
                    else { dotClasses += " bg-slate-700 text-slate-400"; }
                    stepper += `<div class="text-center relative z-10 flex-1"><div class="${dotClasses}">${icon}</div><div class="text-[11px] font-bold">${s}</div></div>`;
                });
                stepper += '</div>';

                let timeline = '<div class="space-y-4 relative pl-5 before:absolute before:top-2 before:bottom-2 before:left-1 before:w-0.5 before:bg-slate-700">';
                (d.history || []).slice().reverse().forEach(h => {
                    timeline += `<div class="relative">
                        <div class="absolute -left-5 top-1 w-2.5 h-2.5 rounded-full bg-amber-500"></div>
                        <div class="font-bold text-sm">${escapeHtml(h.status)} ${h.location ? '&mdash; ' + escapeHtml(h.location) : ''}</div>
                        <div class="text-xs text-slate-400">${escapeHtml(h.timestamp)} ${h.note ? '&bull; ' + escapeHtml(h.note) : ''}</div>
                    </div>`;
                });
                timeline += '</div>';

                const isTerminalBad = (d.status === 'Cancelled' || d.status === 'Delayed');
                const statusColor = isTerminalBad ? 'bg-rose-500/20 text-rose-400' : 'bg-amber-500/20 text-amber-400';

                resultBox.className = "mt-6 p-6 rounded-xl border bg-slate-900 text-white border-slate-800";
                resultBox.innerHTML = `
                    <div class="flex items-center justify-between border-b border-slate-800 pb-3 mb-4 flex-wrap gap-2">
                        <div>
                            <div class="text-xs text-slate-400 font-bold uppercase tracking-wider">Tracking Code</div>
                            <div class="font-mono text-amber-500 font-bold">${escapeHtml(d.code)}</div>
                        </div>
                        <div class="text-right">
                            <div class="text-xs text-slate-400 font-bold uppercase tracking-wider">Status</div>
                            <span class="text-xs font-bold ${statusColor} px-3 py-1 rounded-full">${escapeHtml(d.status.toUpperCase())}</span>
                        </div>
                    </div>
                    <p class="text-slate-400 text-xs mb-2">${escapeHtml(d.origin || '?')} &rarr; ${escapeHtml(d.destination || '?')} &bull; ${escapeHtml(d.item || 'Item')} ${d.weight ? '&bull; ' + escapeHtml(String(d.weight)) + 'kg' : ''} &bull; ${escapeHtml(d.service || '')}</p>
                    ${stepper}
                    <hr class="my-5 border-slate-800">
                    <h4 class="text-sm font-bold mb-3">Shipment History</h4>
                    ${timeline}
                    <div class="mt-5 grid grid-cols-2 gap-3 text-xs">
                        <div class="p-3 bg-slate-800/60 rounded-lg"><strong class="text-slate-300">Receiver:</strong> <span class="text-slate-400">${escapeHtml(d.receiver || '—')}</span></div>
                        <div class="p-3 bg-slate-800/60 rounded-lg"><strong class="text-slate-300">Est. Delivery:</strong> <span class="text-slate-400">${escapeHtml(d.estimated || 'Calculating...')}</span></div>
                    </div>`;
            } catch (err) {
                resultBox.className = "mt-6 p-4 rounded-xl border bg-rose-50 border-rose-200 text-rose-700 font-semibold text-sm";
                resultBox.innerHTML = "<i class='fa-solid fa-triangle-exclamation'></i> Could not reach the tracking server. Please try again.";
            }
        }

        function escapeHtml(str) {
            const div = document.createElement('div');
            div.textContent = str ?? '';
            return div.innerHTML;
        }

        document.getElementById('trackingInput')?.addEventListener('keypress', function (e) {
            if (e.key === 'Enter') trackPackage();
        });

        // Quote form -> api/quote.php
        document.getElementById('quoteForm')?.addEventListener('submit', async function (e) {
            e.preventDefault();
            const form = e.target;
            const feedback = document.getElementById('quoteFeedback');
            const formData = new FormData(form);
            feedback.className = "text-sm font-semibold text-slate-500";
            feedback.textContent = "Sending...";
            try {
                const res = await fetch(`${THQ_API_BASE}/api/quote.php`, { method: 'POST', body: formData });
                const json = await res.json();
                feedback.className = "text-sm font-semibold " + (json.success ? "text-emerald-600" : "text-rose-600");
                feedback.textContent = json.message;
                if (json.success) form.reset();
            } catch (err) {
                feedback.className = "text-sm font-semibold text-rose-600";
                feedback.textContent = "Could not send. Please try again.";
            }
        });
    </script>
</body>
</html>
