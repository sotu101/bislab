
</main>
<footer class="text-center text-xs text-slate-400 py-8">
    THQ Logistics Admin &middot; Standalone PHP, no WordPress required
</footer>
</body>
</html>
