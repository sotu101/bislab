<?php
// Expects $pageTitle to be set by the including page.
$flash = thq_flash_get();
$currentFile = basename($_SERVER['SCRIPT_NAME']);
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo e($pageTitle ?? 'Admin'); ?> · THQ Logistics</title>
<script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
    body{font-family:Inter,system-ui,sans-serif}
    .badge{padding:4px 10px;border-radius:20px;font-size:11px;font-weight:700;display:inline-block}
    .badge-pending{background:#FEF3C7;color:#92400E}
    .badge-transit{background:#DBEAFE;color:#1E40AF}
    .badge-delivered{background:#D1FAE5;color:#065F46}
    .badge-cancel{background:#FEE2E2;color:#991B1B}
    .badge-delayed{background:#FFE4CC;color:#9A3412}
</style>
</head>
<body class="bg-slate-50 text-slate-800 min-h-screen">
<nav class="bg-slate-900 text-white shadow-md">
    <div class="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center flex-wrap gap-3">
        <a href="dashboard.php" class="text-xl font-black tracking-wider text-amber-500 flex items-center gap-2">
            <i class="fa-solid fa-truck-fast"></i> THQ <span class="text-white font-light">ADMIN</span>
        </a>
        <div class="flex items-center gap-6 text-sm font-medium">
            <a href="dashboard.php" class="<?php echo $currentFile === 'dashboard.php' ? 'text-amber-500' : 'hover:text-amber-500'; ?> transition-colors">Dashboard</a>
            <a href="shipments.php" class="<?php echo $currentFile === 'shipments.php' ? 'text-amber-500' : 'hover:text-amber-500'; ?> transition-colors">Shipments</a>
            <a href="add-shipment.php" class="<?php echo $currentFile === 'add-shipment.php' ? 'text-amber-500' : 'hover:text-amber-500'; ?> transition-colors">+ Add New</a>
            <a href="<?php echo e(THQ_BASE_URL); ?>/" class="hover:text-amber-500 transition-colors" target="_blank">View Site <i class="fa-solid fa-arrow-up-right-from-square text-xs"></i></a>
            <span class="text-slate-500">|</span>
            <span class="text-slate-400"><?php echo e(thq_current_admin_username()); ?></span>
            <a href="logout.php" class="bg-slate-800 hover:bg-slate-700 px-3 py-1.5 rounded-lg text-xs font-bold">Logout</a>
        </div>
    </div>
</nav>
<main class="max-w-7xl mx-auto px-6 py-8">
<?php if ($flash): ?>
    <div class="mb-6 p-4 rounded-xl border font-semibold text-sm <?php echo $flash['type'] === 'error' ? 'bg-rose-50 border-rose-200 text-rose-700' : 'bg-emerald-50 border-emerald-200 text-emerald-700'; ?>">
        <i class="fa-solid <?php echo $flash['type'] === 'error' ? 'fa-circle-exclamation' : 'fa-circle-check'; ?>"></i>
        <?php echo e($flash['message']); ?>
    </div>
<?php endif; ?>
