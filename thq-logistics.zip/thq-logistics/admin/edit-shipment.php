<?php
require_once __DIR__ . '/../config.php';
thq_require_login();

$pdo = thq_db();
$id = (int)($_GET['id'] ?? 0);
$shipment = thq_get_shipment($pdo, $id);

if (!$shipment) {
    thq_flash_set('Shipment not found.', 'error');
    thq_redirect('shipments.php');
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    thq_csrf_check();

    $senderName   = thq_text('sender_name');
    $receiverName = thq_text('receiver_name');
    if ($senderName === '') $errors[] = 'Sender name is required.';
    if ($receiverName === '') $errors[] = 'Receiver name is required.';

    if (empty($errors)) {
        $stmt = $pdo->prepare('UPDATE shipments SET
            sender_name=?, sender_phone=?, sender_email=?, sender_address=?,
            receiver_name=?, receiver_phone=?, receiver_email=?, receiver_address=?,
            origin_city=?, destination_city=?, item_name=?, item_description=?, quantity=?,
            weight=?, length=?, width=?, height=?, declared_value=?, is_fragile=?,
            service_type=?, shipping_cost=?, payment_status=?, current_status=?, estimated_delivery=?,
            updated_at=CURRENT_TIMESTAMP
            WHERE id=?');

        $newStatus = thq_text('current_status');

        $stmt->execute([
            $senderName, thq_text('sender_phone'), thq_text('sender_email'), thq_text('sender_address'),
            $receiverName, thq_text('receiver_phone'), thq_text('receiver_email'), thq_text('receiver_address'),
            thq_text('origin_city'), thq_text('destination_city'), thq_text('item_name'), thq_text('item_description'), (int)($_POST['quantity'] ?? 1),
            (float)($_POST['weight'] ?? 0), (float)($_POST['length'] ?? 0), (float)($_POST['width'] ?? 0), (float)($_POST['height'] ?? 0), (float)($_POST['declared_value'] ?? 0), thq_text('is_fragile', 'no'),
            thq_text('service_type', 'Standard'), (float)($_POST['shipping_cost'] ?? 0), thq_text('payment_status', 'Pending'), $newStatus, thq_text('estimated_delivery'),
            $id,
        ]);

        // Optional: append a new history entry if the admin filled in the "add update" panel.
        $historyLocation = thq_text('history_location');
        $historyNote = thq_text('history_note');
        $historyStatus = thq_text('history_status'); // may be blank = keep current status label in the log

        if ($historyLocation !== '' || $historyNote !== '' || $historyStatus !== '') {
            $stmt = $pdo->prepare('INSERT INTO status_history (shipment_id, status, location, note) VALUES (?,?,?,?)');
            $stmt->execute([$id, $historyStatus !== '' ? $historyStatus : $newStatus, $historyLocation, $historyNote]);
        }

        thq_flash_set('Shipment updated.');
        thq_redirect('edit-shipment.php?id=' . $id);
    }
}

// Reload fresh data (covers both the GET case and post-validation-error case)
$shipment = thq_get_shipment($pdo, $id);
$statuses = thq_statuses();
$services = thq_service_types();
$payments = thq_payment_statuses();
$get = function ($key) use ($shipment) { return $shipment[$key] ?? ''; };

$pageTitle = 'Edit Shipment';
include __DIR__ . '/includes/header.php';
?>

<div class="flex items-center justify-between flex-wrap gap-3 mb-1">
    <h1 class="text-2xl font-extrabold tracking-tight text-slate-900">Edit Shipment</h1>
    <span class="text-xl font-extrabold tracking-widest bg-indigo-50 text-indigo-600 px-4 py-2 rounded-xl border border-dashed border-indigo-200"><?php echo e($shipment['tracking_code']); ?></span>
</div>
<p class="text-slate-500 mb-6">Update shipment details or log a new status event below.</p>

<?php if (!empty($errors)): ?>
    <div class="mb-6 p-4 rounded-xl border bg-rose-50 border-rose-200 text-rose-700 font-semibold text-sm">
        <?php foreach ($errors as $err): ?><div><i class="fa-solid fa-circle-exclamation"></i> <?php echo e($err); ?></div><?php endforeach; ?>
    </div>
<?php endif; ?>

<form method="post" class="space-y-6">
    <?php echo thq_csrf_field(); ?>

    <div class="grid md:grid-cols-2 gap-6">
        <div class="bg-white border border-slate-200 rounded-2xl p-6">
            <h3 class="text-xs font-bold uppercase tracking-wider text-slate-500 mb-4">📦 Sender Information</h3>
            <div class="mb-3"><label class="block text-xs font-semibold text-slate-600 mb-1">Full Name</label>
                <input type="text" name="sender_name" required value="<?php echo e($get('sender_name')); ?>" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"></div>
            <div class="grid grid-cols-2 gap-3 mb-3">
                <div><label class="block text-xs font-semibold text-slate-600 mb-1">Phone</label>
                    <input type="text" name="sender_phone" value="<?php echo e($get('sender_phone')); ?>" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"></div>
                <div><label class="block text-xs font-semibold text-slate-600 mb-1">Email</label>
                    <input type="email" name="sender_email" value="<?php echo e($get('sender_email')); ?>" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"></div>
            </div>
            <div><label class="block text-xs font-semibold text-slate-600 mb-1">Address</label>
                <textarea name="sender_address" rows="2" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"><?php echo e($get('sender_address')); ?></textarea></div>
        </div>

        <div class="bg-white border border-slate-200 rounded-2xl p-6">
            <h3 class="text-xs font-bold uppercase tracking-wider text-slate-500 mb-4">🏠 Receiver Information</h3>
            <div class="mb-3"><label class="block text-xs font-semibold text-slate-600 mb-1">Full Name</label>
                <input type="text" name="receiver_name" required value="<?php echo e($get('receiver_name')); ?>" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"></div>
            <div class="grid grid-cols-2 gap-3 mb-3">
                <div><label class="block text-xs font-semibold text-slate-600 mb-1">Phone</label>
                    <input type="text" name="receiver_phone" value="<?php echo e($get('receiver_phone')); ?>" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"></div>
                <div><label class="block text-xs font-semibold text-slate-600 mb-1">Email</label>
                    <input type="email" name="receiver_email" value="<?php echo e($get('receiver_email')); ?>" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"></div>
            </div>
            <div><label class="block text-xs font-semibold text-slate-600 mb-1">Address</label>
                <textarea name="receiver_address" rows="2" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"><?php echo e($get('receiver_address')); ?></textarea></div>
        </div>
    </div>

    <div class="grid md:grid-cols-2 gap-6">
        <div class="bg-white border border-slate-200 rounded-2xl p-6">
            <h3 class="text-xs font-bold uppercase tracking-wider text-slate-500 mb-4">📋 Item Details</h3>
            <div class="mb-3"><label class="block text-xs font-semibold text-slate-600 mb-1">Item Name</label>
                <input type="text" name="item_name" value="<?php echo e($get('item_name')); ?>" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"></div>
            <div class="mb-3"><label class="block text-xs font-semibold text-slate-600 mb-1">Description</label>
                <textarea name="item_description" rows="2" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"><?php echo e($get('item_description')); ?></textarea></div>
            <div class="grid grid-cols-2 gap-3 mb-3">
                <div><label class="block text-xs font-semibold text-slate-600 mb-1">Quantity</label>
                    <input type="number" name="quantity" min="1" value="<?php echo e($get('quantity') ?: 1); ?>" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"></div>
                <div><label class="block text-xs font-semibold text-slate-600 mb-1">Weight (kg)</label>
                    <input type="number" step="0.01" name="weight" value="<?php echo e($get('weight')); ?>" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"></div>
            </div>
            <div class="grid grid-cols-3 gap-3 mb-3">
                <div><label class="block text-xs font-semibold text-slate-600 mb-1">Length cm</label>
                    <input type="number" step="0.1" name="length" value="<?php echo e($get('length')); ?>" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"></div>
                <div><label class="block text-xs font-semibold text-slate-600 mb-1">Width cm</label>
                    <input type="number" step="0.1" name="width" value="<?php echo e($get('width')); ?>" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"></div>
                <div><label class="block text-xs font-semibold text-slate-600 mb-1">Height cm</label>
                    <input type="number" step="0.1" name="height" value="<?php echo e($get('height')); ?>" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"></div>
            </div>
            <div class="grid grid-cols-2 gap-3">
                <div><label class="block text-xs font-semibold text-slate-600 mb-1">Declared Value <?php echo e(THQ_CURRENCY); ?></label>
                    <input type="number" name="declared_value" value="<?php echo e($get('declared_value')); ?>" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"></div>
                <div><label class="block text-xs font-semibold text-slate-600 mb-1">Fragile?</label>
                    <select name="is_fragile" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500">
                        <option value="no" <?php echo $get('is_fragile') === 'no' ? 'selected' : ''; ?>>No</option>
                        <option value="yes" <?php echo $get('is_fragile') === 'yes' ? 'selected' : ''; ?>>Yes - Handle with care</option>
                    </select></div>
            </div>
        </div>

        <div class="bg-white border border-slate-200 rounded-2xl p-6">
            <h3 class="text-xs font-bold uppercase tracking-wider text-slate-500 mb-4">🚚 Logistics &amp; Status</h3>
            <div class="grid grid-cols-2 gap-3 mb-3">
                <div><label class="block text-xs font-semibold text-slate-600 mb-1">Origin City</label>
                    <input type="text" name="origin_city" value="<?php echo e($get('origin_city')); ?>" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"></div>
                <div><label class="block text-xs font-semibold text-slate-600 mb-1">Destination City</label>
                    <input type="text" name="destination_city" value="<?php echo e($get('destination_city')); ?>" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"></div>
            </div>
            <div class="mb-3"><label class="block text-xs font-semibold text-slate-600 mb-1">Current Status</label>
                <select name="current_status" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500">
                    <?php foreach ($statuses as $s): ?><option value="<?php echo e($s); ?>" <?php echo $get('current_status') === $s ? 'selected' : ''; ?>><?php echo e($s); ?></option><?php endforeach; ?>
                </select></div>
            <div class="grid grid-cols-2 gap-3 mb-3">
                <div><label class="block text-xs font-semibold text-slate-600 mb-1">Service Type</label>
                    <select name="service_type" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500">
                        <?php foreach ($services as $s): ?><option value="<?php echo e($s); ?>" <?php echo $get('service_type') === $s ? 'selected' : ''; ?>><?php echo e($s); ?></option><?php endforeach; ?>
                    </select></div>
                <div><label class="block text-xs font-semibold text-slate-600 mb-1">Payment</label>
                    <select name="payment_status" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500">
                        <?php foreach ($payments as $s): ?><option value="<?php echo e($s); ?>" <?php echo $get('payment_status') === $s ? 'selected' : ''; ?>><?php echo e($s); ?></option><?php endforeach; ?>
                    </select></div>
            </div>
            <div class="grid grid-cols-2 gap-3">
                <div><label class="block text-xs font-semibold text-slate-600 mb-1">Shipping Cost <?php echo e(THQ_CURRENCY); ?></label>
                    <input type="number" name="shipping_cost" value="<?php echo e($get('shipping_cost')); ?>" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"></div>
                <div><label class="block text-xs font-semibold text-slate-600 mb-1">Est. Delivery</label>
                    <input type="date" name="estimated_delivery" value="<?php echo e($get('estimated_delivery')); ?>" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"></div>
            </div>

            <div class="mt-4 p-4 bg-slate-50 rounded-xl border border-dashed border-slate-300">
                <h4 class="text-xs font-bold mb-2">+ Log a Status Update (appends to history below)</h4>
                <div class="grid grid-cols-2 gap-3 mb-2">
                    <div><label class="block text-xs font-semibold text-slate-600 mb-1">Status label (optional)</label>
                        <select name="history_status" class="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm">
                            <option value="">-- use Current Status above --</option>
                            <?php foreach ($statuses as $s): ?><option value="<?php echo e($s); ?>"><?php echo e($s); ?></option><?php endforeach; ?>
                        </select></div>
                    <div><label class="block text-xs font-semibold text-slate-600 mb-1">Location</label>
                        <input type="text" name="history_location" placeholder="e.g. Ibadan Hub" class="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"></div>
                </div>
                <label class="block text-xs font-semibold text-slate-600 mb-1">Note</label>
                <input type="text" name="history_note" placeholder="e.g. Arrived at sorting facility" class="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm">
            </div>
        </div>
    </div>

    <div class="flex justify-end gap-3">
        <a href="shipments.php" class="px-6 py-3 rounded-xl font-semibold text-slate-600 hover:bg-slate-100">Back to List</a>
        <button type="submit" class="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold px-8 py-3 rounded-xl">Save Changes</button>
    </div>
</form>

<?php if (!empty($shipment['history'])): ?>
<div class="bg-white border border-slate-200 rounded-2xl p-6 mt-6">
    <h3 class="text-xs font-bold uppercase tracking-wider text-slate-500 mb-4">🕒 Tracking History</h3>
    <div class="border-l-2 border-slate-200 pl-5 space-y-4">
        <?php foreach (array_reverse($shipment['history']) as $h): ?>
            <div class="relative">
                <div class="absolute -left-[26px] top-1 w-3 h-3 bg-indigo-500 rounded-full border-2 border-white ring-2 ring-indigo-100"></div>
                <div class="font-bold text-sm"><?php echo e($h['status']); ?> <?php echo $h['location'] ? '— ' . e($h['location']) : ''; ?></div>
                <div class="text-xs text-slate-500"><?php echo e($h['created_at']); ?> <?php echo $h['note'] ? '• ' . e($h['note']) : ''; ?></div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<?php include __DIR__ . '/includes/footer.php'; ?>
