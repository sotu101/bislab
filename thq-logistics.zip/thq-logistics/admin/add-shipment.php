<?php
require_once __DIR__ . '/../config.php';
thq_require_login();

$pdo = thq_db();
$errors = [];

// A fresh suggested code is generated every time this form is loaded.
$suggestedCode = thq_generate_tracking_code($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    thq_csrf_check();

    $senderName    = thq_text('sender_name');
    $receiverName  = thq_text('receiver_name');

    if ($senderName === '') $errors[] = 'Sender name is required.';
    if ($receiverName === '') $errors[] = 'Receiver name is required.';

    if (empty($errors)) {
        // Honor the code the admin was shown, unless it somehow got taken in the meantime.
        $code = strtoupper(thq_text('tracking_code'));
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM shipments WHERE tracking_code = ?');
        $stmt->execute([$code]);
        if ($code === '' || (int)$stmt->fetchColumn() > 0) {
            $code = thq_generate_tracking_code($pdo);
        }

        $stmt = $pdo->prepare('INSERT INTO shipments (
            tracking_code, sender_name, sender_phone, sender_email, sender_address,
            receiver_name, receiver_phone, receiver_email, receiver_address,
            origin_city, destination_city, item_name, item_description, quantity,
            weight, length, width, height, declared_value, is_fragile,
            service_type, shipping_cost, payment_status, current_status, estimated_delivery
        ) VALUES (?,?,?,?,?, ?,?,?,?, ?,?,?,?,?, ?,?,?,?,?,?, ?,?,?,?,?)');

        $stmt->execute([
            $code, $senderName, thq_text('sender_phone'), thq_text('sender_email'), thq_text('sender_address'),
            $receiverName, thq_text('receiver_phone'), thq_text('receiver_email'), thq_text('receiver_address'),
            thq_text('origin_city'), thq_text('destination_city'), thq_text('item_name'), thq_text('item_description'), (int)($_POST['quantity'] ?? 1),
            (float)($_POST['weight'] ?? 0), (float)($_POST['length'] ?? 0), (float)($_POST['width'] ?? 0), (float)($_POST['height'] ?? 0), (float)($_POST['declared_value'] ?? 0), thq_text('is_fragile', 'no'),
            thq_text('service_type', 'Standard'), (float)($_POST['shipping_cost'] ?? 0), thq_text('payment_status', 'Pending'), thq_text('current_status', 'Pending'), thq_text('estimated_delivery'),
        ]);

        $shipmentId = (int)$pdo->lastInsertId();

        $stmt = $pdo->prepare('INSERT INTO status_history (shipment_id, status, location, note) VALUES (?,?,?,?)');
        $stmt->execute([
            $shipmentId,
            thq_text('current_status', 'Pending'),
            thq_text('origin_city') ?: 'Origin',
            'Shipment created and tracking code generated',
        ]);

        thq_flash_set("Shipment created. Tracking code: $code");
        thq_redirect('edit-shipment.php?id=' . $shipmentId);
    }
}

$statuses = thq_statuses();
$services = thq_service_types();
$payments = thq_payment_statuses();

$pageTitle = 'Add New Shipment';
include __DIR__ . '/includes/header.php';
?>

<h1 class="text-2xl font-extrabold tracking-tight text-slate-900 mb-1">Add New Shipment</h1>
<p class="text-slate-500 mb-6">Fill in the parcel details below. The tracking code is generated automatically.</p>

<?php if (!empty($errors)): ?>
    <div class="mb-6 p-4 rounded-xl border bg-rose-50 border-rose-200 text-rose-700 font-semibold text-sm">
        <?php foreach ($errors as $err): ?><div><i class="fa-solid fa-circle-exclamation"></i> <?php echo e($err); ?></div><?php endforeach; ?>
    </div>
<?php endif; ?>

<form method="post" class="space-y-6">
    <?php echo thq_csrf_field(); ?>

    <div class="bg-white border border-slate-200 rounded-2xl p-6">
        <label class="font-bold text-sm block mb-2">Tracking Code (Auto-Generated &amp; Unique)</label>
        <span class="text-2xl font-extrabold tracking-widest bg-indigo-50 text-indigo-600 px-4 py-2.5 rounded-xl inline-block border border-dashed border-indigo-200"><?php echo e($suggestedCode); ?></span>
        <input type="hidden" name="tracking_code" value="<?php echo e($suggestedCode); ?>">
        <p class="text-xs text-slate-500 mt-2">Format: <?php echo e(THQ_TRACKING_PREFIX); ?>-XXXX-XXXX-XXX &bull; Random, non-sequential for security</p>
    </div>

    <div class="grid md:grid-cols-2 gap-6">
        <div class="bg-white border border-slate-200 rounded-2xl p-6">
            <h3 class="text-xs font-bold uppercase tracking-wider text-slate-500 mb-4">📦 Sender Information</h3>
            <div class="mb-3"><label class="block text-xs font-semibold text-slate-600 mb-1">Full Name</label>
                <input type="text" name="sender_name" required class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"></div>
            <div class="grid grid-cols-2 gap-3 mb-3">
                <div><label class="block text-xs font-semibold text-slate-600 mb-1">Phone</label>
                    <input type="text" name="sender_phone" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"></div>
                <div><label class="block text-xs font-semibold text-slate-600 mb-1">Email</label>
                    <input type="email" name="sender_email" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"></div>
            </div>
            <div><label class="block text-xs font-semibold text-slate-600 mb-1">Address</label>
                <textarea name="sender_address" rows="2" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"></textarea></div>
        </div>

        <div class="bg-white border border-slate-200 rounded-2xl p-6">
            <h3 class="text-xs font-bold uppercase tracking-wider text-slate-500 mb-4">🏠 Receiver Information</h3>
            <div class="mb-3"><label class="block text-xs font-semibold text-slate-600 mb-1">Full Name</label>
                <input type="text" name="receiver_name" required class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"></div>
            <div class="grid grid-cols-2 gap-3 mb-3">
                <div><label class="block text-xs font-semibold text-slate-600 mb-1">Phone</label>
                    <input type="text" name="receiver_phone" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"></div>
                <div><label class="block text-xs font-semibold text-slate-600 mb-1">Email</label>
                    <input type="email" name="receiver_email" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"></div>
            </div>
            <div><label class="block text-xs font-semibold text-slate-600 mb-1">Address</label>
                <textarea name="receiver_address" rows="2" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"></textarea></div>
        </div>
    </div>

    <div class="grid md:grid-cols-2 gap-6">
        <div class="bg-white border border-slate-200 rounded-2xl p-6">
            <h3 class="text-xs font-bold uppercase tracking-wider text-slate-500 mb-4">📋 Item Details</h3>
            <div class="mb-3"><label class="block text-xs font-semibold text-slate-600 mb-1">Item Name</label>
                <input type="text" name="item_name" placeholder="e.g. Electronics - iPhone 14" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"></div>
            <div class="mb-3"><label class="block text-xs font-semibold text-slate-600 mb-1">Description</label>
                <textarea name="item_description" rows="2" placeholder="Color, model, etc." class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"></textarea></div>
            <div class="grid grid-cols-2 gap-3 mb-3">
                <div><label class="block text-xs font-semibold text-slate-600 mb-1">Quantity</label>
                    <input type="number" name="quantity" value="1" min="1" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"></div>
                <div><label class="block text-xs font-semibold text-slate-600 mb-1">Weight (kg)</label>
                    <input type="number" step="0.01" name="weight" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"></div>
            </div>
            <div class="grid grid-cols-3 gap-3 mb-3">
                <div><label class="block text-xs font-semibold text-slate-600 mb-1">Length cm</label>
                    <input type="number" step="0.1" name="length" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"></div>
                <div><label class="block text-xs font-semibold text-slate-600 mb-1">Width cm</label>
                    <input type="number" step="0.1" name="width" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"></div>
                <div><label class="block text-xs font-semibold text-slate-600 mb-1">Height cm</label>
                    <input type="number" step="0.1" name="height" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"></div>
            </div>
            <div class="grid grid-cols-2 gap-3">
                <div><label class="block text-xs font-semibold text-slate-600 mb-1">Declared Value <?php echo e(THQ_CURRENCY); ?></label>
                    <input type="number" name="declared_value" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"></div>
                <div><label class="block text-xs font-semibold text-slate-600 mb-1">Fragile?</label>
                    <select name="is_fragile" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500">
                        <option value="no">No</option>
                        <option value="yes">Yes - Handle with care</option>
                    </select></div>
            </div>
        </div>

        <div class="bg-white border border-slate-200 rounded-2xl p-6">
            <h3 class="text-xs font-bold uppercase tracking-wider text-slate-500 mb-4">🚚 Logistics &amp; Status</h3>
            <div class="grid grid-cols-2 gap-3 mb-3">
                <div><label class="block text-xs font-semibold text-slate-600 mb-1">Origin City</label>
                    <input type="text" name="origin_city" placeholder="Lagos" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"></div>
                <div><label class="block text-xs font-semibold text-slate-600 mb-1">Destination City</label>
                    <input type="text" name="destination_city" placeholder="Ibadan" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"></div>
            </div>
            <div class="mb-3"><label class="block text-xs font-semibold text-slate-600 mb-1">Current Status</label>
                <select name="current_status" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500">
                    <?php foreach ($statuses as $s): ?><option value="<?php echo e($s); ?>"><?php echo e($s); ?></option><?php endforeach; ?>
                </select></div>
            <div class="grid grid-cols-2 gap-3 mb-3">
                <div><label class="block text-xs font-semibold text-slate-600 mb-1">Service Type</label>
                    <select name="service_type" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500">
                        <?php foreach ($services as $s): ?><option value="<?php echo e($s); ?>"><?php echo e($s); ?></option><?php endforeach; ?>
                    </select></div>
                <div><label class="block text-xs font-semibold text-slate-600 mb-1">Payment</label>
                    <select name="payment_status" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500">
                        <?php foreach ($payments as $s): ?><option value="<?php echo e($s); ?>"><?php echo e($s); ?></option><?php endforeach; ?>
                    </select></div>
            </div>
            <div class="grid grid-cols-2 gap-3">
                <div><label class="block text-xs font-semibold text-slate-600 mb-1">Shipping Cost <?php echo e(THQ_CURRENCY); ?></label>
                    <input type="number" name="shipping_cost" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"></div>
                <div><label class="block text-xs font-semibold text-slate-600 mb-1">Est. Delivery</label>
                    <input type="date" name="estimated_delivery" class="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"></div>
            </div>
        </div>
    </div>

    <div class="flex justify-end gap-3">
        <a href="shipments.php" class="px-6 py-3 rounded-xl font-semibold text-slate-600 hover:bg-slate-100">Cancel</a>
        <button type="submit" class="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold px-8 py-3 rounded-xl">Create Shipment</button>
    </div>
</form>

<?php include __DIR__ . '/includes/footer.php'; ?>
