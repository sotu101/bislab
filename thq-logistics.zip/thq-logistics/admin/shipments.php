<?php
require_once __DIR__ . '/../config.php';
thq_require_login();

$pdo = thq_db();

// Handle delete
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    thq_csrf_check();
    $stmt = $pdo->prepare('DELETE FROM shipments WHERE id = ?');
    $stmt->execute([(int)$_POST['delete_id']]);
    thq_flash_set('Shipment deleted.');
    thq_redirect('shipments.php');
}

$search = trim($_GET['q'] ?? '');
$statusFilter = $_GET['status'] ?? '';

$sql = 'SELECT * FROM shipments WHERE 1=1';
$params = [];
if ($search !== '') {
    $sql .= ' AND (tracking_code LIKE ? OR receiver_name LIKE ? OR sender_name LIKE ?)';
    $like = '%' . $search . '%';
    $params[] = $like; $params[] = $like; $params[] = $like;
}
if ($statusFilter !== '') {
    $sql .= ' AND current_status = ?';
    $params[] = $statusFilter;
}
$sql .= ' ORDER BY id DESC LIMIT 200';

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$shipments = $stmt->fetchAll();

$pageTitle = 'Shipments';
include __DIR__ . '/includes/header.php';
?>

<div class="flex items-center justify-between flex-wrap gap-4 mb-6">
    <h1 class="text-2xl font-extrabold tracking-tight text-slate-900">All Shipments</h1>
    <a href="add-shipment.php" class="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold px-5 py-2.5 rounded-xl text-sm">+ Add New Shipment</a>
</div>

<form method="get" class="flex flex-wrap gap-3 mb-6">
    <input type="text" name="q" value="<?php echo e($search); ?>" placeholder="Search tracking code, receiver, sender..."
        class="flex-1 min-w-[240px] px-4 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500">
    <select name="status" class="px-4 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500">
        <option value="">All statuses</option>
        <?php foreach (thq_statuses() as $s): ?>
            <option value="<?php echo e($s); ?>" <?php echo $statusFilter === $s ? 'selected' : ''; ?>><?php echo e($s); ?></option>
        <?php endforeach; ?>
    </select>
    <button type="submit" class="bg-slate-900 hover:bg-slate-800 text-white px-5 py-2.5 rounded-xl text-sm font-semibold">Filter</button>
    <?php if ($search !== '' || $statusFilter !== ''): ?>
        <a href="shipments.php" class="px-4 py-2.5 text-sm font-semibold text-slate-500 hover:text-slate-800">Clear</a>
    <?php endif; ?>
</form>

<div class="bg-white border border-slate-200 rounded-2xl overflow-hidden">
    <div class="overflow-x-auto">
    <table class="w-full text-sm border-collapse">
        <tr class="text-left text-[11px] uppercase text-slate-500 bg-slate-50">
            <th class="py-3 px-4">Tracking Code</th>
            <th class="py-3 px-4">Receiver</th>
            <th class="py-3 px-4">Route</th>
            <th class="py-3 px-4">Service</th>
            <th class="py-3 px-4">Status</th>
            <th class="py-3 px-4">Date</th>
            <th class="py-3 px-4"></th>
        </tr>
        <?php if (empty($shipments)): ?>
            <tr><td colspan="7" class="text-center text-slate-400 py-10">No shipments match your search.</td></tr>
        <?php endif; ?>
        <?php foreach ($shipments as $s): ?>
            <tr class="border-t border-slate-100 hover:bg-slate-50">
                <td class="py-3 px-4"><code class="bg-indigo-50 text-indigo-600 px-2 py-1 rounded-md font-bold text-xs"><?php echo e($s['tracking_code']); ?></code></td>
                <td class="py-3 px-4"><?php echo e($s['receiver_name'] ?: '—'); ?></td>
                <td class="py-3 px-4"><?php echo e(($s['origin_city'] ?: '?') . ' → ' . ($s['destination_city'] ?: '?')); ?></td>
                <td class="py-3 px-4 text-slate-500"><?php echo e($s['service_type']); ?></td>
                <td class="py-3 px-4"><span class="badge <?php echo thq_status_badge_class($s['current_status']); ?>"><?php echo e($s['current_status']); ?></span></td>
                <td class="py-3 px-4 text-slate-500"><?php echo e(date('M j, Y', strtotime($s['created_at']))); ?></td>
                <td class="py-3 px-4 text-right whitespace-nowrap">
                    <a href="edit-shipment.php?id=<?php echo (int)$s['id']; ?>" class="text-amber-600 font-semibold text-xs mr-3">Edit</a>
                    <form method="post" class="inline" onsubmit="return confirm('Delete this shipment permanently?');">
                        <?php echo thq_csrf_field(); ?>
                        <input type="hidden" name="delete_id" value="<?php echo (int)$s['id']; ?>">
                        <button type="submit" class="text-rose-500 font-semibold text-xs">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
