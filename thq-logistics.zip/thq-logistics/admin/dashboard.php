<?php
require_once __DIR__ . '/../config.php';
thq_require_login();

$pdo = thq_db();
$total = (int)$pdo->query('SELECT COUNT(*) FROM shipments')->fetchColumn();

$counts = [];
foreach ($pdo->query('SELECT current_status, COUNT(*) as c FROM shipments GROUP BY current_status') as $row) {
    $counts[$row['current_status']] = (int)$row['c'];
}
$inTransit = ($counts['In Transit'] ?? 0) + ($counts['At Hub'] ?? 0) + ($counts['Out for Delivery'] ?? 0);
$delivered = $counts['Delivered'] ?? 0;
$pending   = $counts['Pending'] ?? 0;

$recent = $pdo->query('SELECT * FROM shipments ORDER BY id DESC LIMIT 8')->fetchAll();

$pageTitle = 'Dashboard';
include __DIR__ . '/includes/header.php';
?>

<h1 class="text-2xl font-extrabold tracking-tight text-slate-900">SwiftTrack Dashboard</h1>
<p class="text-slate-500 mb-6">Manage all shipments from one place. Tracking codes are auto-generated and unique.</p>

<div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
    <div class="bg-white border border-slate-200 rounded-2xl p-5">
        <div class="text-[11px] uppercase tracking-wider text-slate-500 font-bold">Total Shipments</div>
        <div class="text-3xl font-extrabold mt-1"><?php echo $total; ?></div>
        <div class="text-xs text-emerald-600 mt-1">All time</div>
    </div>
    <div class="bg-white border border-slate-200 rounded-2xl p-5">
        <div class="text-[11px] uppercase tracking-wider text-slate-500 font-bold">In Transit</div>
        <div class="text-3xl font-extrabold mt-1 text-blue-600"><?php echo $inTransit; ?></div>
        <div class="text-xs text-slate-500 mt-1">Moving now</div>
    </div>
    <div class="bg-white border border-slate-200 rounded-2xl p-5">
        <div class="text-[11px] uppercase tracking-wider text-slate-500 font-bold">Delivered</div>
        <div class="text-3xl font-extrabold mt-1 text-emerald-600"><?php echo $delivered; ?></div>
        <div class="text-xs text-slate-500 mt-1">Completed</div>
    </div>
    <div class="bg-white border border-slate-200 rounded-2xl p-5">
        <div class="text-[11px] uppercase tracking-wider text-slate-500 font-bold">Pending Pickup</div>
        <div class="text-3xl font-extrabold mt-1 text-amber-600"><?php echo $pending; ?></div>
        <div class="text-xs text-slate-500 mt-1">Needs action</div>
    </div>
</div>

<div class="grid lg:grid-cols-[2.2fr_.8fr] gap-6">
    <div class="bg-white border border-slate-200 rounded-2xl p-6">
        <h3 class="font-bold mb-3">Recent Shipments</h3>
        <div class="overflow-x-auto">
        <table class="w-full text-sm border-collapse">
            <tr class="text-left text-[11px] uppercase text-slate-500">
                <th class="py-2 border-b border-slate-200">Tracking Code</th>
                <th class="py-2 border-b border-slate-200">Receiver</th>
                <th class="py-2 border-b border-slate-200">Route</th>
                <th class="py-2 border-b border-slate-200">Status</th>
                <th class="py-2 border-b border-slate-200">Date</th>
                <th class="py-2 border-b border-slate-200"></th>
            </tr>
            <?php if (empty($recent)): ?>
                <tr><td colspan="6" class="text-center text-slate-400 py-8">No shipments yet. <a href="add-shipment.php" class="text-amber-600 font-semibold">Create your first one</a>.</td></tr>
            <?php endif; ?>
            <?php foreach ($recent as $s): ?>
                <tr class="border-b border-slate-100">
                    <td class="py-3"><code class="bg-indigo-50 text-indigo-600 px-2 py-1 rounded-md font-bold text-xs"><?php echo e($s['tracking_code']); ?></code></td>
                    <td class="py-3"><?php echo e($s['receiver_name'] ?: '—'); ?></td>
                    <td class="py-3"><?php echo e(($s['origin_city'] ?: '?') . ' → ' . ($s['destination_city'] ?: '?')); ?></td>
                    <td class="py-3"><span class="badge <?php echo thq_status_badge_class($s['current_status']); ?>"><?php echo e($s['current_status']); ?></span></td>
                    <td class="py-3 text-slate-500"><?php echo e(date('M j, Y', strtotime($s['created_at']))); ?></td>
                    <td class="py-3"><a href="edit-shipment.php?id=<?php echo (int)$s['id']; ?>" class="text-amber-600 font-semibold text-xs">Edit &rarr;</a></td>
                </tr>
            <?php endforeach; ?>
        </table>
        </div>
    </div>
    <div class="bg-white border border-slate-200 rounded-2xl p-6">
        <h3 class="font-bold mb-3">Quick Actions</h3>
        <a href="add-shipment.php" class="block text-center w-full bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold py-2.5 rounded-xl">+ New Shipment</a>
        <a href="shipments.php" class="block text-center w-full border border-slate-200 hover:bg-slate-50 font-semibold py-2.5 rounded-xl mt-2">View All Shipments</a>
        <hr class="my-5 border-slate-100">
        <h4 class="font-bold text-sm mb-1">Public tracking</h4>
        <p class="text-xs text-slate-500 leading-relaxed">Customers track shipments right on the homepage — no plugin or shortcode needed.</p>
        <div class="bg-slate-50 border border-slate-200 p-2.5 rounded-lg font-mono text-xs mt-2 break-all"><?php echo e(THQ_BASE_URL); ?>/#track</div>
        <hr class="my-5 border-slate-100">
        <h4 class="font-bold text-sm mb-1">How codes work</h4>
        <p class="text-xs text-slate-500 leading-relaxed"><?php echo e(THQ_TRACKING_PREFIX); ?>-XXXX-XXXX-XXX, randomly generated, excludes confusing characters (I, O, 0, 1), checked for uniqueness automatically.</p>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
