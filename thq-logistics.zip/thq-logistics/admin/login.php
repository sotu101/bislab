<?php
require_once __DIR__ . '/../config.php';

if (thq_is_logged_in()) {
    thq_redirect('dashboard.php');
}

$pdo = thq_db();
$isFirstRun = !thq_admin_exists($pdo);
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    thq_csrf_check();

    if ($isFirstRun) {
        $username = thq_text('username');
        $password = $_POST['password'] ?? '';
        $confirm  = $_POST['confirm'] ?? '';

        if ($username === '' || $password === '') {
            $error = 'Please choose a username and password.';
        } elseif (strlen($password) < 8) {
            $error = 'Password must be at least 8 characters.';
        } elseif ($password !== $confirm) {
            $error = 'Passwords do not match.';
        } else {
            thq_create_admin($pdo, $username, $password);
            thq_attempt_login($pdo, $username, $password);
            thq_flash_set('Admin account created. Welcome to THQ Logistics!');
            thq_redirect('dashboard.php');
        }
    } else {
        $username = thq_text('username');
        $password = $_POST['password'] ?? '';
        if (thq_attempt_login($pdo, $username, $password)) {
            thq_redirect('dashboard.php');
        } else {
            $error = 'Incorrect username or password.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo $isFirstRun ? 'Create Admin Account' : 'Admin Login'; ?> · THQ Logistics</title>
<script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-slate-950 min-h-screen flex items-center justify-center p-6 font-sans">
    <div class="w-full max-w-md">
        <div class="text-center mb-8">
            <a href="<?php echo e(THQ_BASE_URL); ?>/" class="text-2xl font-black tracking-wider text-amber-500 inline-flex items-center gap-2">
                <i class="fa-solid fa-truck-fast"></i> THQ <span class="text-white font-light">LOGISTICS</span>
            </a>
        </div>
        <div class="bg-slate-900 border border-slate-800 rounded-2xl p-8 shadow-2xl">
            <?php if ($isFirstRun): ?>
                <h1 class="text-xl font-bold text-white mb-1">Create your admin account</h1>
                <p class="text-slate-400 text-sm mb-6">No admin account exists yet. Set one up now to manage shipments.</p>
            <?php else: ?>
                <h1 class="text-xl font-bold text-white mb-1">Admin Login</h1>
                <p class="text-slate-400 text-sm mb-6">Sign in to manage shipments.</p>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="mb-4 p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-400 text-sm font-semibold">
                    <i class="fa-solid fa-circle-exclamation"></i> <?php echo e($error); ?>
                </div>
            <?php endif; ?>

            <form method="post" class="space-y-4">
                <?php echo thq_csrf_field(); ?>
                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">Username</label>
                    <input type="text" name="username" required autofocus
                        class="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-amber-500">
                </div>
                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">Password</label>
                    <input type="password" name="password" required
                        class="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-amber-500">
                </div>
                <?php if ($isFirstRun): ?>
                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">Confirm Password</label>
                    <input type="password" name="confirm" required
                        class="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-amber-500">
                </div>
                <?php endif; ?>
                <button type="submit" class="w-full bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold py-3 rounded-xl transition-all">
                    <?php echo $isFirstRun ? 'Create Account & Log In' : 'Log In'; ?>
                </button>
            </form>
        </div>
        <p class="text-center text-slate-600 text-xs mt-6">
            <a href="<?php echo e(THQ_BASE_URL); ?>/" class="hover:text-slate-400">&larr; Back to site</a>
        </p>
    </div>
</body>
</html>
