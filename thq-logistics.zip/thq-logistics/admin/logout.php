<?php
require_once __DIR__ . '/../config.php';
thq_logout();
thq_redirect('login.php');
